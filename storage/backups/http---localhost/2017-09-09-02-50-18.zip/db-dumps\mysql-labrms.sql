
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `labrms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `labrms`;
DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `repeating` tinyint(1) NOT NULL,
  `repeatingFormat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facultyview`;
/*!50001 DROP VIEW IF EXISTS `facultyview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `facultyview` (
  `lastname` tinyint NOT NULL,
  `firstname` tinyint NOT NULL,
  `middlename` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemtype_id` int(10) unsigned NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `warranty` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `profileditems` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_itemtype_id_foreign` (`itemtype_id`),
  CONSTRAINT `inventory_itemtype_id_foreign` FOREIGN KEY (`itemtype_id`) REFERENCES `itemtype` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,5,'Bravia','LP-3027','Ut aut tempora et totam.','Ipsa, incididunt dolorem magnam cupidatat.','Unit',468,30,'2017-09-06 23:26:41','2017-09-06 23:27:08');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_log` (
  `log_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `facultyincharge` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `item_log_log_id_foreign` (`log_id`),
  KEY `item_log_item_id_foreign` (`item_id`),
  CONSTRAINT `item_log_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `pc` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `item_log_log_id_foreign` FOREIGN KEY (`log_id`) REFERENCES `log` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `item_log` WRITE;
/*!40000 ALTER TABLE `item_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_reservation_reservation_id_foreign` (`reservation_id`),
  KEY `item_reservation_item_id_foreign` (`item_id`),
  CONSTRAINT `item_reservation_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `itemprofile` (`id`),
  CONSTRAINT `item_reservation_reservation_id_foreign` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `item_reservation` WRITE;
/*!40000 ALTER TABLE `item_reservation` DISABLE KEYS */;
INSERT INTO `item_reservation` VALUES (1,1,1,NULL),(2,2,1,NULL);
/*!40000 ALTER TABLE `item_reservation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_ticket_item_id_foreign` (`item_id`),
  KEY `item_ticket_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `item_ticket_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `item_ticket_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `item_ticket` WRITE;
/*!40000 ALTER TABLE `item_ticket` DISABLE KEYS */;
INSERT INTO `item_ticket` VALUES (1,1,1,NULL,NULL),(2,2,2,NULL,NULL),(3,3,3,NULL,NULL),(4,4,4,NULL,NULL),(5,5,5,NULL,NULL),(6,6,6,NULL,NULL),(7,7,7,NULL,NULL),(8,8,8,NULL,NULL),(9,9,9,NULL,NULL),(10,10,10,NULL,NULL),(11,11,11,NULL,NULL),(12,12,12,NULL,NULL),(13,13,13,NULL,NULL),(14,14,14,NULL,NULL),(15,15,15,NULL,NULL),(16,16,16,NULL,NULL),(17,17,17,NULL,NULL),(18,18,18,NULL,NULL),(19,19,19,NULL,NULL),(20,20,20,NULL,NULL),(21,21,21,NULL,NULL),(22,22,22,NULL,NULL),(23,23,23,NULL,NULL),(24,24,24,NULL,NULL),(25,25,25,NULL,NULL),(26,26,26,NULL,NULL),(27,27,27,NULL,NULL),(28,28,28,NULL,NULL),(29,29,29,NULL,NULL),(30,30,30,NULL,NULL);
/*!40000 ALTER TABLE `item_ticket` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_v`;
/*!50001 DROP VIEW IF EXISTS `item_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `item_v` (
  `itemtype` tinyint NOT NULL,
  `category` tinyint NOT NULL,
  `brand` tinyint NOT NULL,
  `model` tinyint NOT NULL,
  `details` tinyint NOT NULL,
  `propertynumber` tinyint NOT NULL,
  `serialnumber` tinyint NOT NULL,
  `status` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `itemprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemprofile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` int(10) unsigned NOT NULL,
  `receipt_id` int(10) unsigned NOT NULL,
  `propertynumber` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serialnumber` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datereceived` date DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lent_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deployment_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemprofile_inventory_id_foreign` (`inventory_id`),
  KEY `itemprofile_receipt_id_foreign` (`receipt_id`),
  CONSTRAINT `itemprofile_inventory_id_foreign` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `itemprofile_receipt_id_foreign` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `itemprofile` WRITE;
/*!40000 ALTER TABLE `itemprofile` DISABLE KEYS */;
INSERT INTO `itemprofile` VALUES (1,1,1,'PUP-5-94-3110','HA6HZ3T4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:05','2017-09-06 23:27:05',NULL),(2,1,1,'PUP-5-94-3111','PX8PP2K3','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:06','2017-09-06 23:27:06',NULL),(3,1,1,'PUP-5-94-3112','ZH2WS7W4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:07','2017-09-06 23:27:07',NULL),(4,1,1,'PUP-5-94-3113','HM8QT0G8','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:07','2017-09-06 23:27:07',NULL),(5,1,1,'PUP-5-94-3114','LO9OG1M0','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(6,1,1,'PUP-5-94-3115','YO0XS4R4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,1,1,'PUP-5-94-3116','PY8HM6A9','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(8,1,1,'PUP-5-94-3117','WN7ER9M7','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(9,1,1,'PUP-5-94-3118','LB3DK6H3','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(10,1,1,'PUP-5-94-3119','AV0HX3P8','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(11,1,1,'PUP-5-94-3120','DV2HP7R4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(12,1,1,'PUP-5-94-3121','SA9QP7G7','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(13,1,1,'PUP-5-94-3122','IY0MC0Q0','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(14,1,1,'PUP-5-94-3123','MK9JG6S8','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(15,1,1,'PUP-5-94-3124','YV4KN5L6','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(16,1,1,'PUP-5-94-3125','JE5MI2E8','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(17,1,1,'PUP-5-94-3126','ZF8EG6J8','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(18,1,1,'PUP-5-94-3127','EE2JJ9E0','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(19,1,1,'PUP-5-94-3128','RI6YF8N3','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(20,1,1,'PUP-5-94-3129','BI0DS5L6','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(21,1,1,'PUP-5-94-3130','FD1KB4K6','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(22,1,1,'PUP-5-94-3131','IR2FK3M7','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(23,1,1,'PUP-5-94-3132','LK5TD5T4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(24,1,1,'PUP-5-94-3133','OT0RS6O0','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(25,1,1,'PUP-5-94-3134','EB0SG5N5','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(26,1,1,'PUP-5-94-3135','IF2XT2G4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(27,1,1,'PUP-5-94-3136','AC0YM3G1','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(28,1,1,'PUP-5-94-3137','PJ3OE1W2','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(29,1,1,'PUP-5-94-3138','DW7GD2D4','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(30,1,1,'PUP-5-94-3139','KY7LQ6U6','Server','2017-09-07','working',NULL,NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL);
/*!40000 ALTER TABLE `itemprofile` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `itemtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `itemtype_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `itemtype` WRITE;
/*!40000 ALTER TABLE `itemtype` DISABLE KEYS */;
INSERT INTO `itemtype` VALUES (1,'System Unit','Computer set','equipment',NULL,NULL,NULL),(2,'Display','Visual aids','equipment',NULL,NULL,NULL),(3,'AVR','Power Regulator','equipment',NULL,NULL,NULL),(4,'Aircon','Cooling appliance','equipment',NULL,NULL,NULL),(5,'TV','Visual aids','equipment',NULL,NULL,NULL),(6,'Projector','Visual aids','equipment',NULL,NULL,NULL),(7,'Extension','Extension cord or any other power source','supply',NULL,NULL,NULL),(8,'Keyboard','Computer parts used as an input','equipment',NULL,NULL,NULL),(9,'Mouse','','supply',NULL,NULL,NULL);
/*!40000 ALTER TABLE `itemtype` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `flag` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abbr` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `native` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `default` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English','','en','Latn','English',1,1,NULL,NULL,NULL),(2,'Romanian','','ro','Latn','română',1,0,NULL,NULL,NULL),(3,'French','','fr','Latn','français',0,0,NULL,NULL,NULL),(4,'Italian','','it','Latn','italiano',0,0,NULL,NULL,NULL),(5,'Spanish','','es','Latn','español',0,0,NULL,NULL,NULL),(6,'German','','de','Latn','Deutsch',0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lendlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lendlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middlename` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courseyearsection` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facultyincharge` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timein` datetime NOT NULL,
  `timeout` datetime DEFAULT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lendlog_item_id_foreign` (`item_id`),
  CONSTRAINT `lendlog_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `itemprofile` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lendlog` WRITE;
/*!40000 ALTER TABLE `lendlog` DISABLE KEYS */;
INSERT INTO `lendlog` VALUES (1,'Blair','Carson','Thornton','1973','Only, Administrator','S501','2017-09-07 07:28:55','2017-09-07 07:29:09',1,'2017-09-06 23:28:55','2017-09-06 23:29:09');
/*!40000 ALTER TABLE `lendlog` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `time` datetime NOT NULL,
  `inout` tinyint(1) NOT NULL,
  `computers` tinyint(1) NOT NULL,
  `peripherals` tinyint(1) NOT NULL,
  `light` tinyint(1) NOT NULL,
  `aircon` tinyint(1) NOT NULL,
  `clean` tinyint(1) NOT NULL,
  `notes` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_user_id_foreign` (`user_id`),
  CONSTRAINT `log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `maintenanceactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenanceactivity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `maintenanceactivity` WRITE;
/*!40000 ALTER TABLE `maintenanceactivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenanceactivity` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `maintenanceactivity_itemtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenanceactivity_itemtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `maintenanceactivity_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `itemtype_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `maintenanceactivity_itemtype` WRITE;
/*!40000 ALTER TABLE `maintenanceactivity_itemtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenanceactivity_itemtype` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_resets_table',1),(2,'2017_03_03_090505_create_room_table',1),(3,'2017_03_03_090731_create_user_table',1),(4,'2017_03_03_093611_create_inventory_table',1),(5,'2017_04_15_133308_create_facultyview_table',1),(6,'2017_04_20_164307_create_receipt_table',1),(7,'2017_04_20_164352_create_itemprofile_table',1),(8,'2017_04_20_164430_create_pc_table',1),(9,'2017_04_27_130357_create_reservation_table',1),(10,'2017_04_27_130512_create_item_reservation_table',1),(11,'2017_04_27_184408_create_roominventory_table',1),(12,'2017_05_02_094457_create_ticket_table',1),(13,'2017_05_02_105252_create_payment_table',1),(14,'2017_05_02_105653_create_software_table',1),(15,'2017_05_02_110439_create_softwarelicense_table',1),(16,'2017_05_02_111028_create_pc_software_table',1),(17,'2017_05_02_111604_create_log_table',1),(18,'2017_05_02_111618_create_item_log_table',1),(19,'2017_05_02_111804_create_room_log_table',1),(20,'2017_05_09_053619_create_itemtype_table',1),(21,'2017_05_09_053840_create_inventory_foreign_key',1),(22,'2017_05_23_081235_create_tickettype_table',1),(23,'2017_05_23_081559_create_reservationitems_table',1),(24,'2017_06_06_015221_create_purpose_table',1),(25,'2017_06_10_055559_create_event_table',1),(26,'2017_07_08_070808_create_supply_table',1),(27,'2017_07_08_071004_create_supplyhistory_table',1),(28,'2017_07_11_143017_create_room_software_table',1),(29,'2017_07_18_202846_create_user_ticket_table',1),(30,'2017_07_18_203106_create_room_ticket_table',1),(31,'2017_07_18_203134_create_item_ticket_table',1),(32,'2017_07_18_204026_create_pc_ticket_table',1),(33,'2017_07_21_011939_create_maintenanceactivity_table',1),(34,'2017_07_21_012045_create_maintenanceactivityitemtype_table',1),(35,'2017_08_03_154117_create_session_table',1),(36,'2017_08_13_075534_create_ticketview_table',1),(37,'2017_08_13_184707_create_roomschedule_table',1),(38,'2017_08_22_064333_create_tickettrigger',1),(39,'2017_08_25_163545_create_softwaretype_table',1),(40,'2017_08_25_164702_create_roomcategory_table',1),(41,'2017_08_25_180044_create_room_reservation_table',1),(42,'2017_08_25_181039_create_room_reservationview_table',1),(43,'2017_08_27_215445_create_lendlog_table',1),(44,'2017_08_28_052338_create_systemtime_table',1),(45,'2017_08_28_094440_create_itemview_table',1),(46,'2017_08_28_102253_create_reservationitemsview_table',1),(47,'2017_09_03_164618_create_reserveditemsview_table',1),(48,'2015_09_07_190535_create_languages_table',2),(49,'2015_09_10_124414_alter_languages_table',2),(50,'2015_08_04_131614_create_settings_table',3),(51,'2016_05_25_121918_create_pages_table',3),(52,'2017_04_10_195926_change_extras_to_longtext',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `extras` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `ORno` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receivedby` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_item_id_foreign` (`item_id`),
  CONSTRAINT `payment_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `itemprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `systemunit_id` int(10) unsigned NOT NULL,
  `monitor_id` int(10) unsigned DEFAULT NULL,
  `keyboard_id` int(10) unsigned DEFAULT NULL,
  `avr_id` int(10) unsigned DEFAULT NULL,
  `oskey` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mouse` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pc_systemunit_id_foreign` (`systemunit_id`),
  KEY `pc_monitor_id_foreign` (`monitor_id`),
  KEY `pc_keyboard_id_foreign` (`keyboard_id`),
  KEY `pc_avr_id_foreign` (`avr_id`),
  CONSTRAINT `pc_avr_id_foreign` FOREIGN KEY (`avr_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pc_keyboard_id_foreign` FOREIGN KEY (`keyboard_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pc_monitor_id_foreign` FOREIGN KEY (`monitor_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pc_systemunit_id_foreign` FOREIGN KEY (`systemunit_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pc` WRITE;
/*!40000 ALTER TABLE `pc` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pc_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc_software` (
  `pc_id` int(10) unsigned NOT NULL,
  `software_id` int(10) unsigned NOT NULL,
  `softwarelicense_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  KEY `pc_software_pc_id_foreign` (`pc_id`),
  KEY `pc_software_software_id_foreign` (`software_id`),
  KEY `pc_software_softwarelicense_id_foreign` (`softwarelicense_id`),
  CONSTRAINT `pc_software_pc_id_foreign` FOREIGN KEY (`pc_id`) REFERENCES `pc` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pc_software_software_id_foreign` FOREIGN KEY (`software_id`) REFERENCES `software` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pc_software_softwarelicense_id_foreign` FOREIGN KEY (`softwarelicense_id`) REFERENCES `softwarelicense` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pc_software` WRITE;
/*!40000 ALTER TABLE `pc_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc_software` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pc_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pc_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pc_id` int(10) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pc_ticket_pc_id_foreign` (`pc_id`),
  KEY `pc_ticket_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `pc_ticket_pc_id_foreign` FOREIGN KEY (`pc_id`) REFERENCES `pc` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pc_ticket_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pc_ticket` WRITE;
/*!40000 ALTER TABLE `pc_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `pc_ticket` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purpose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purpose` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purpose_title_unique` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purpose` WRITE;
/*!40000 ALTER TABLE `purpose` DISABLE KEYS */;
INSERT INTO `purpose` VALUES (1,'Oral Defense','',NULL,NULL,NULL),(2,'General Assembly','',NULL,NULL,NULL),(3,'Seminar','',NULL,NULL,NULL),(4,'Tutorial','',NULL,NULL,NULL),(5,'Make-up Classes','',NULL,NULL,NULL),(6,'Class Presentation','',NULL,NULL,NULL),(7,'Class Activity','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `purpose` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inventory_id` int(10) unsigned NOT NULL,
  `POno` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `POdate` date DEFAULT NULL,
  `invoiceno` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `fundcode` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receipt_inventory_id_foreign` (`inventory_id`),
  CONSTRAINT `receipt_inventory_id_foreign` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `receipt` WRITE;
/*!40000 ALTER TABLE `receipt` DISABLE KEYS */;
INSERT INTO `receipt` VALUES (1,'88-93-272',1,'2211825','2017-09-07','4084374','2017-09-07','94012');
/*!40000 ALTER TABLE `receipt` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `timein` datetime NOT NULL,
  `timeout` datetime NOT NULL,
  `purpose` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approval` tinyint(1) NOT NULL,
  `facultyincharge` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservation_user_id_foreign` (`user_id`),
  CONSTRAINT `reservation_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1,1,'2017-09-10 15:30:00','2017-09-10 17:00:00','Seminar','S501',2,'Only, Administrator ','kulang sa info','2017-09-06 23:31:51','2017-09-07 21:25:23'),(2,1,'2017-09-11 13:23:00','2017-09-11 13:53:00','Oral Defense','S501',2,'Only, Administrator ','walang pera','2017-09-07 21:23:58','2017-09-07 21:24:53');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reservationitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservationitems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemtype_id` int(10) unsigned NOT NULL,
  `inventory_id` int(10) unsigned NOT NULL,
  `included` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excluded` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reservationitems_itemtype_id_foreign` (`itemtype_id`),
  KEY `reservationitems_inventory_id_foreign` (`inventory_id`),
  CONSTRAINT `reservationitems_inventory_id_foreign` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `reservationitems_itemtype_id_foreign` FOREIGN KEY (`itemtype_id`) REFERENCES `itemtype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reservationitems` WRITE;
/*!40000 ALTER TABLE `reservationitems` DISABLE KEYS */;
INSERT INTO `reservationitems` VALUES (1,5,1,'','','Enabled');
/*!40000 ALTER TABLE `reservationitems` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reservationitems_v`;
/*!50001 DROP VIEW IF EXISTS `reservationitems_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `reservationitems_v` (
  `name` tinyint NOT NULL,
  `model` tinyint NOT NULL,
  `brand` tinyint NOT NULL,
  `id` tinyint NOT NULL,
  `propertynumber` tinyint NOT NULL,
  `status` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `reserveditems_v`;
/*!50001 DROP VIEW IF EXISTS `reserveditems_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `reserveditems_v` (
  `lastname` tinyint NOT NULL,
  `middlename` tinyint NOT NULL,
  `firstname` tinyint NOT NULL,
  `itemtype` tinyint NOT NULL,
  `brand` tinyint NOT NULL,
  `model` tinyint NOT NULL,
  `propertynumber` tinyint NOT NULL,
  `timein` tinyint NOT NULL,
  `timeout` tinyint NOT NULL,
  `purpose` tinyint NOT NULL,
  `location` tinyint NOT NULL,
  `approval` tinyint NOT NULL,
  `facultyincharge` tinyint NOT NULL,
  `remark` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,'S501','Web Development',NULL,NULL,NULL),(2,'S502','Networking',NULL,NULL,NULL),(3,'S503','Networking',NULL,NULL,NULL),(4,'S504','Hardware,Networking',NULL,NULL,NULL),(5,'Consultation Room','Consultation,Meeting',NULL,NULL,NULL),(6,'Faculty Room','Faculty Area',NULL,NULL,NULL),(7,'Server','',NULL,NULL,NULL),(8,'S508','Programming,Web Development',NULL,NULL,NULL),(9,'S510','Database,Web Development,Multimedia',NULL,NULL,NULL),(10,'S511','Multimedia',NULL,NULL,NULL);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `room_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_id` int(10) unsigned DEFAULT NULL,
  `logout_id` int(10) unsigned DEFAULT NULL,
  `room_id` int(10) unsigned NOT NULL,
  `facultyincharge` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_log_login_id_foreign` (`login_id`),
  KEY `room_log_logout_id_foreign` (`logout_id`),
  KEY `room_log_room_id_foreign` (`room_id`),
  CONSTRAINT `room_log_login_id_foreign` FOREIGN KEY (`login_id`) REFERENCES `log` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `room_log_logout_id_foreign` FOREIGN KEY (`logout_id`) REFERENCES `log` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `room_log_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `room_log` WRITE;
/*!40000 ALTER TABLE `room_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `room_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_software` (
  `room_id` int(10) unsigned NOT NULL,
  `software_id` int(10) unsigned NOT NULL,
  `softwarelicense_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`,`software_id`),
  KEY `room_software_software_id_foreign` (`software_id`),
  KEY `room_software_softwarelicense_id_foreign` (`softwarelicense_id`),
  CONSTRAINT `room_software_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `room_software_software_id_foreign` FOREIGN KEY (`software_id`) REFERENCES `software` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `room_software_softwarelicense_id_foreign` FOREIGN KEY (`softwarelicense_id`) REFERENCES `softwarelicense` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `room_software` WRITE;
/*!40000 ALTER TABLE `room_software` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_software` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `room_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_ticket_room_id_foreign` (`room_id`),
  KEY `room_ticket_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `room_ticket_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `room_ticket_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `room_ticket` WRITE;
/*!40000 ALTER TABLE `room_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_ticket` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roomcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomcategory` (
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roomcategory` WRITE;
/*!40000 ALTER TABLE `roomcategory` DISABLE KEYS */;
INSERT INTO `roomcategory` VALUES ('systems development laboratory'),('software application laboratory'),('programming laboratory'),('multimedia laboratory'),('computerhardware laboratory');
/*!40000 ALTER TABLE `roomcategory` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roominventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roominventory` (
  `room_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `roominventory_room_id_foreign` (`room_id`),
  CONSTRAINT `roominventory_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `itemprofile` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `roominventory_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roominventory` WRITE;
/*!40000 ALTER TABLE `roominventory` DISABLE KEYS */;
INSERT INTO `roominventory` VALUES (7,1,'2017-09-06 23:27:05','2017-09-06 23:27:05',NULL),(7,2,'2017-09-06 23:27:07','2017-09-06 23:27:07',NULL),(7,3,'2017-09-06 23:27:07','2017-09-06 23:27:07',NULL),(7,4,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,5,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,6,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,7,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,8,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,9,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,10,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,11,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,12,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,13,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,14,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,15,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,16,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,17,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,18,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,19,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,20,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,21,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,22,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,23,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,24,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,25,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,26,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,27,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,28,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,29,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL),(7,30,'2017-09-06 23:27:08','2017-09-06 23:27:08',NULL);
/*!40000 ALTER TABLE `roominventory` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roomreservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomreservation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` int(10) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roomreservation_reservation_id_foreign` (`reservation_id`),
  KEY `roomreservation_room_id_foreign` (`room_id`),
  CONSTRAINT `roomreservation_reservation_id_foreign` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`),
  CONSTRAINT `roomreservation_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roomreservation` WRITE;
/*!40000 ALTER TABLE `roomreservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `roomreservation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roomreservation_v`;
/*!50001 DROP VIEW IF EXISTS `roomreservation_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `roomreservation_v` (
  `lastname` tinyint NOT NULL,
  `firstname` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `timein` tinyint NOT NULL,
  `timeout` tinyint NOT NULL,
  `purpose` tinyint NOT NULL,
  `location` tinyint NOT NULL,
  `approval` tinyint NOT NULL,
  `facultyincharge` tinyint NOT NULL,
  `remark` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `roomschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomschedule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `faculty` int(11) DEFAULT NULL,
  `academicyear` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roomschedule_room_id_foreign` (`room_id`),
  CONSTRAINT `roomschedule_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roomschedule` WRITE;
/*!40000 ALTER TABLE `roomschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `roomschedule` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `field` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `software` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `softwarename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `softwaretype` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `licensetype` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minsysreq` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxsysreq` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `software` WRITE;
/*!40000 ALTER TABLE `software` DISABLE KEYS */;
/*!40000 ALTER TABLE `software` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `softwarelicense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwarelicense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `software_id` int(10) unsigned NOT NULL,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `multipleuse` tinyint(1) NOT NULL,
  `inuse` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `softwarelicense_software_id_foreign` (`software_id`),
  CONSTRAINT `softwarelicense_software_id_foreign` FOREIGN KEY (`software_id`) REFERENCES `software` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `softwarelicense` WRITE;
/*!40000 ALTER TABLE `softwarelicense` DISABLE KEYS */;
/*!40000 ALTER TABLE `softwarelicense` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `softwaretype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `softwaretype` (
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `softwaretype` WRITE;
/*!40000 ALTER TABLE `softwaretype` DISABLE KEYS */;
INSERT INTO `softwaretype` VALUES ('Word processing Software'),('Database Software'),('Spreadsheet Software'),('Multimedia Software'),('Presentation Software'),('Enterprise Software'),('Information Worker Software'),('Educational Software'),('Simulation Software'),('Content Access Software'),('Application Suites'),('Engineering and Product Development Software');
/*!40000 ALTER TABLE `softwaretype` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemtype_id` int(10) unsigned NOT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supply_itemtype_id_foreign` (`itemtype_id`),
  CONSTRAINT `supply_itemtype_id_foreign` FOREIGN KEY (`itemtype_id`) REFERENCES `itemtype` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `supply` WRITE;
/*!40000 ALTER TABLE `supply` DISABLE KEYS */;
/*!40000 ALTER TABLE `supply` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `supplyhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplyhistory` (
  `supply_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `remark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personinvolve` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `supplyhistory_supply_id_foreign` (`supply_id`),
  CONSTRAINT `supplyhistory_supply_id_foreign` FOREIGN KEY (`supply_id`) REFERENCES `supply` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `supplyhistory` WRITE;
/*!40000 ALTER TABLE `supplyhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplyhistory` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `systemtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemtime` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `academicyear` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datestart` date NOT NULL,
  `dateend` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `systemtime` WRITE;
/*!40000 ALTER TABLE `systemtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemtime` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tickettype` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticketname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staffassigned` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ticket_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `ticket_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (1,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:05','2017-09-06 23:27:05'),(2,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:06','2017-09-06 23:27:06'),(3,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:07','2017-09-06 23:27:07'),(4,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:07','2017-09-06 23:27:07'),(5,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(6,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(7,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(8,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(9,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(10,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(11,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(12,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(13,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(14,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(15,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(16,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(17,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(18,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(19,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(20,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(21,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(22,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(23,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(24,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(25,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(26,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(27,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(28,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(29,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(30,'Receive','Equipment Profiling','Equipment profiled on 2017-09-07 by Administrator  Only. ','Administrator  Only','1',NULL,'Closed',NULL,'2017-09-06 23:27:08','2017-09-06 23:27:08'),(31,'Complaint','Consectetur laboris in esse veniam v','Dolorem rerum ex voluptatem. Est qui fugiat cupiditate et magni.','Shaeleigh Randall','1',NULL,'Open',NULL,'2017-09-07 21:14:15','2017-09-07 21:14:15');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ticket_trg` 
            AFTER INSERT ON `ticket`
            FOR EACH ROW BEGIN 

                SET @item_ticket = (
                    SELECT ticket_id 
                    FROM item_ticket 
                    WHERE ticket_id = new.ticket_id
                );

                SET @pc_ticket = (
                    SELECT ticket_id 
                    FROM pc_ticket 
                    WHERE ticket_id = new.ticket_id
                );

                SET @room_ticket = (
                    SELECT ticket_id 
                    FROM room_ticket 
                    WHERE ticket_id = new.ticket_id
                );

                SET @item_id = (
                    SELECT item_id 
                    FROM item_ticket 
                    WHERE ticket_id = new.ticket_id
                );
                SET @pc_id = (
                    SELECT pc_id 
                    FROM pc_ticket 
                    WHERE ticket_id = new.ticket_id
                );
                SET @room_id = (
                    SELECT room_id 
                    FROM room_ticket 
                    WHERE ticket_id = new.ticket_id
                );

                IF @item_ticket IS NOT NULL THEN
                    INSERT INTO item_ticket(item_id,ticket_id) 
                    VALUES (@item_id,new.id);
                ELSEIF @pc_ticket IS NOT NULL THEN
                    INSERT INTO pc_ticket(pc_id,ticket_id) 
                    VALUES (@pc_id,new.id);
                ELSEIF @room_ticket IS NOT NULL THEN
                    INSERT INTO room_ticket(room_id,ticket_id) 
                    VALUES (@room_id,new.id);
                END IF;
                
            END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
DROP TABLE IF EXISTS `ticket_v`;
/*!50001 DROP VIEW IF EXISTS `ticket_v`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `ticket_v` (
  `id` tinyint NOT NULL,
  `date` tinyint NOT NULL,
  `title` tinyint NOT NULL,
  `details` tinyint NOT NULL,
  `tickettype` tinyint NOT NULL,
  `tag` tinyint NOT NULL,
  `staffassigned` tinyint NOT NULL,
  `staff_id` tinyint NOT NULL,
  `author` tinyint NOT NULL,
  `status` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `tickettype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickettype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickettype_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tickettype` WRITE;
/*!40000 ALTER TABLE `tickettype` DISABLE KEYS */;
INSERT INTO `tickettype` VALUES (1,'Complaint',NULL,NULL),(2,'Action Taken',NULL,NULL),(3,'Transfer',NULL,NULL),(4,'Maintenance',NULL,NULL),(5,'Lent',NULL,NULL),(6,'Incident',NULL,NULL);
/*!40000 ALTER TABLE `tickettype` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accesslevel` int(11) NOT NULL,
  `firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middlename` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactnumber` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2y$10$V1oGnkT21PTv6f99iCF8k.iqvAQoRo5weUsX1TtnLmo9QW31eppYO',0,'Administrator','','Only','09123456789','pup.ccis.server@gmail.com','faculty',1,'2017-09-05 06:09:49','2017-09-07 04:23:04','e2psUj5vcIAVO3vT3yxQ2qu8av0aazU0adcXwhrje14TFrNfrXSkGa1FJmNE',NULL),(2,'labassistant','$2y$10$hDPe6ZfJ8drBixSuczGMduSm/rU3d7aWpnrf9R9o9E2ZB3.BdmgBK',1,'Laboratory','','Assistant','09123456789','labassistant@yahoo.com','faculty',1,'2017-09-05 06:09:50','2017-09-05 06:09:50',NULL,NULL),(3,'labstaff','$2y$10$vkR7lSzluFeMPLGAT6wbOuO90t7L/RyTNR4zBlimcQdqwxX3zpA4e',2,'Laboratory','','Staff','09123456789','labstaff@yahoo.com','faculty',1,'2017-09-05 06:09:51','2017-09-05 06:09:51','9spHScLFf32VwzmtZh6sqKBX5pZLnDcK69BDSuapF8sTZHCIihjalGWXr7yn',NULL),(4,'faculty','$2y$10$NLV6qOC4SUmCkQCEVSfhaOhNI2eYwrGtihzA4yXxOiS9elZXmu03u',3,'Faculty','','Office','09123456789','faculty@yahoo.com','faculty',1,'2017-09-05 06:09:51','2017-09-05 06:09:51',NULL,NULL),(5,'student','$2y$10$3sFS224LfIjdIqm1qqgW3eQMORaaI/KFCTkomwS5t.rlDMXp9eNDu',4,'John','','Doe','09123456789','johndoe@yahoo.com','student',1,'2017-09-05 06:09:51','2017-09-05 06:09:51',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_ticket_user_id_foreign` (`user_id`),
  KEY `user_ticket_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `user_ticket_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_ticket_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_ticket` WRITE;
/*!40000 ALTER TABLE `user_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_ticket` ENABLE KEYS */;
UNLOCK TABLES;

USE `labrms`;
/*!50001 DROP TABLE IF EXISTS `facultyview`*/;
/*!50001 DROP VIEW IF EXISTS `facultyview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `facultyview` AS select `user`.`lastname` AS `lastname`,`user`.`firstname` AS `firstname`,`user`.`middlename` AS `middlename` from `user` where (`user`.`type` in ('faculty','FACULTY','Faculty')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `item_v`*/;
/*!50001 DROP VIEW IF EXISTS `item_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `item_v` AS select `itemtype`.`name` AS `itemtype`,`itemtype`.`category` AS `category`,`inventory`.`brand` AS `brand`,`inventory`.`model` AS `model`,`inventory`.`details` AS `details`,`itemprofile`.`propertynumber` AS `propertynumber`,`itemprofile`.`serialnumber` AS `serialnumber`,`itemprofile`.`status` AS `status` from ((`inventory` join `itemtype` on((`inventory`.`itemtype_id` = `itemtype`.`id`))) join `itemprofile` on((`itemprofile`.`inventory_id` = `inventory`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `reservationitems_v`*/;
/*!50001 DROP VIEW IF EXISTS `reservationitems_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reservationitems_v` AS select `itemtype`.`name` AS `name`,`inventory`.`model` AS `model`,`inventory`.`brand` AS `brand`,`itemprofile`.`id` AS `id`,`itemprofile`.`propertynumber` AS `propertynumber`,`reservationitems`.`status` AS `status` from (((`inventory` join `itemtype` on((`inventory`.`itemtype_id` = `itemtype`.`id`))) join `reservationitems` on(((`reservationitems`.`inventory_id` = `inventory`.`id`) and (`reservationitems`.`itemtype_id` = `itemtype`.`id`)))) join `itemprofile` on((`itemprofile`.`inventory_id` = `inventory`.`id`))) where (`reservationitems`.`status` in ('E','e','Enabled','enabled','Enable','enable')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `reserveditems_v`*/;
/*!50001 DROP VIEW IF EXISTS `reserveditems_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reserveditems_v` AS select `user`.`lastname` AS `lastname`,`user`.`middlename` AS `middlename`,`user`.`firstname` AS `firstname`,`itemtype`.`name` AS `itemtype`,`inventory`.`brand` AS `brand`,`inventory`.`model` AS `model`,`itemprofile`.`propertynumber` AS `propertynumber`,`reservation`.`timein` AS `timein`,`reservation`.`timeout` AS `timeout`,`reservation`.`purpose` AS `purpose`,`reservation`.`location` AS `location`,`reservation`.`approval` AS `approval`,`reservation`.`facultyincharge` AS `facultyincharge`,`reservation`.`remark` AS `remark` from (((((`item_reservation` join `reservation` on((`item_reservation`.`reservation_id` = `reservation`.`id`))) join `itemprofile` on((`itemprofile`.`id` = `item_reservation`.`item_id`))) join `inventory` on((`inventory`.`id` = `itemprofile`.`inventory_id`))) join `user` on((`reservation`.`user_id` = `user`.`id`))) join `itemtype` on((`inventory`.`itemtype_id` = `itemtype`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `roomreservation_v`*/;
/*!50001 DROP VIEW IF EXISTS `roomreservation_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `roomreservation_v` AS select `user`.`lastname` AS `lastname`,`user`.`firstname` AS `firstname`,`room`.`name` AS `name`,`reservation`.`timein` AS `timein`,`reservation`.`timeout` AS `timeout`,`reservation`.`purpose` AS `purpose`,`reservation`.`location` AS `location`,`reservation`.`approval` AS `approval`,`reservation`.`facultyincharge` AS `facultyincharge`,`reservation`.`remark` AS `remark` from (((`roomreservation` join `reservation` on((`roomreservation`.`reservation_id` = `reservation`.`id`))) join `room` on((`room`.`id` = `roomreservation`.`room_id`))) join `user` on((`reservation`.`user_id` = `user`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP TABLE IF EXISTS `ticket_v`*/;
/*!50001 DROP VIEW IF EXISTS `ticket_v`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticket_v` AS select `ticket`.`id` AS `id`,`ticket`.`created_at` AS `date`,`ticket`.`ticketname` AS `title`,`ticket`.`details` AS `details`,`ticket`.`tickettype` AS `tickettype`,concat('Item: ',`itemprofile`.`propertynumber`) AS `tag`,concat(`user`.`firstname`,' ',`user`.`lastname`) AS `staffassigned`,`ticket`.`staffassigned` AS `staff_id`,`ticket`.`author` AS `author`,`ticket`.`status` AS `status` from (((((`ticket` join `item_ticket` on((`item_ticket`.`ticket_id` = `ticket`.`id`))) join `itemprofile` on((`itemprofile`.`id` = `item_ticket`.`item_id`))) join `inventory` on((`itemprofile`.`inventory_id` = `inventory`.`id`))) join `itemtype` on((`inventory`.`itemtype_id` = `itemtype`.`id`))) join `user` on((`user`.`id` = `ticket`.`staffassigned`))) where (`itemtype`.`name` <> 'System Unit') union select `ticket`.`id` AS `id`,`ticket`.`created_at` AS `date`,`ticket`.`ticketname` AS `title`,`ticket`.`details` AS `details`,`ticket`.`tickettype` AS `tickettype`,concat('PC: ',`itemprofile`.`propertynumber`) AS `tag`,concat(`user`.`firstname`,' ',`user`.`lastname`) AS `staffassigned`,`ticket`.`staffassigned` AS `staff_id`,`ticket`.`author` AS `author`,`ticket`.`status` AS `status` from ((((`ticket` left join `user` on((`user`.`id` = `ticket`.`staffassigned`))) join `pc_ticket` on((`pc_ticket`.`ticket_id` = `ticket`.`id`))) join `pc` on((`pc`.`id` = `pc_ticket`.`pc_id`))) join `itemprofile` on((`itemprofile`.`id` = `pc`.`systemunit_id`))) union select `ticket`.`id` AS `id`,`ticket`.`created_at` AS `date`,`ticket`.`ticketname` AS `title`,`ticket`.`details` AS `details`,`ticket`.`tickettype` AS `tickettype`,concat('Room: ',`room`.`name`) AS `tag`,concat(`user`.`firstname`,' ',`user`.`lastname`) AS `staffassigned`,`ticket`.`staffassigned` AS `staff_id`,`ticket`.`author` AS `author`,`ticket`.`status` AS `status` from (((`ticket` left join `user` on((`user`.`id` = `ticket`.`staffassigned`))) join `room_ticket` on((`room_ticket`.`ticket_id` = `ticket`.`id`))) join `room` on((`room`.`id` = `room_ticket`.`room_id`))) union select `ticket`.`id` AS `id`,`ticket`.`created_at` AS `date`,`ticket`.`ticketname` AS `title`,`ticket`.`details` AS `details`,`ticket`.`tickettype` AS `tickettype`,'None' AS `tag`,concat(`user`.`firstname`,' ',`user`.`lastname`) AS `staffassigned`,`ticket`.`staffassigned` AS `staff_id`,`ticket`.`author` AS `author`,`ticket`.`status` AS `status` from (`ticket` left join `user` on((`user`.`id` = `ticket`.`staffassigned`))) where (not(`ticket`.`id` in (select `room_ticket`.`ticket_id` from `room_ticket` union select `item_ticket`.`ticket_id` from `item_ticket` union select `pc_ticket`.`ticket_id` from `pc_ticket`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


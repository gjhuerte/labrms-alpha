<div class="modal fade" id="reservationRulesModal" tabindex="-1" role="dialog" aria-labelledby="reservationRulesModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h3 style="color:#337ab7;">Rules</h3>
			</div>
			<div class="modal-body">
    		<div id="calendar"></div>
			</div> <!-- end of modal-body -->
		</div> <!-- end of modal-content -->
	</div>
</div>
<?php

return [

    // DO NOT ALLOW EDITS ON THESE LANGUAGE FILES
    // Language files to NOT show in the LangFile Manager
    //
    'language_ignore' => ['pagination', 'reminders', 'validation', 'log', 'crud'],

];
